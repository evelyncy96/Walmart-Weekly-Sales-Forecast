#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec 27 23:24:05 2021

@author: haochunniu
"""
import pandas as pd
import numpy as np

#Import Train Data and Check for NA values
train=pd.read_csv('train.csv')
train.head()
train.info()
train.describe(include='all')
train['Date']=pd.to_datetime(train['Date']) #Convert Date column into Datetime 
train.isnull().sum() #There's no NULL value in the train data
train['Date'].min()
train['Date'].max()
train['Store'].unique()

#Import Features Data and Check for NA values
features=pd.read_csv('features.csv')
features.head()
features.info()
features.describe(include='all')
features['Date']=pd.to_datetime(features['Date'])
features.isnull().sum()
features[features.CPI.isnull()]['Date'].min()
features[features.CPI.isnull()]['Date'].max()
features['Store'].unique()
features['Unemployment']

#Import Store Data and Check for NA values
store=pd.read_csv('stores.csv')
store.head()
store.info()
store.describe()
store['Store'].unique()

#Merge Features and Store data with Train, using 'Store'
train_new=pd.merge(train,features.drop(['IsHoliday'],axis='columns'),how='left',on=['Store','Date'])
train_new.info()
train_new=pd.merge(train_new,store,how='left',on='Store')
train_new.info()
train_new.isnull().sum() #Only the Markdown1~5 have Null Values

#Write the result out to a csv file
train_new.to_csv('train_all.csv')
